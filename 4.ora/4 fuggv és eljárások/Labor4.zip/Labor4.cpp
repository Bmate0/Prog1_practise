// Labor4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Labor4.h"

void Eljaras1(int n)
{
    std::cout << "Eljaras1\n";
}

void Eljaras2(int m);

int Negyzet(int n) {
    return n * n;
}

void Eljaras3(int n, int *valtozo)
{
    *valtozo = n;
}

void Eljaras4(int n, int& valtozo)
{
    ;
}

void Eljaras2(int m) {
    std::cout << m << std::endl;
}

void modosit(int* N, int index, int n)
{
    N[index] = n;
}

int main()
{
    int v = 0;
    Eljaras3(3, &v);
    std::cout << v << std::endl;
    std::cout << "Hello World!\n";
    /*
    - Dinamikusan foglaljanak le egy 12 elem� eg�sz t�mb�t!
    - T�lts�k fel -5 �s 20 k�z�tti v�letlenszer� eg�sz �rt�kekkel!
    - �rjanak egy elj�r�st, amely a felhaszn�l� �ltal megadott �rt�kkel m�dos�tja a t�mb azon
      elem�t, amelyet szint�n a felhaszn�l� v�lasztott ki!
    */

    int* N = new int[12];
    
    for (int i = 0; i < 12; i++)
        N[i] = rand() % (20 + 1 - (-5)) - 5;

    int index, n;
    std::cin >> index;
    std::cin >> n;

    modosit(N,index,n);

    char c = 98;
    
	delete[] N;
    /*
    - Foglaljanak le dinamikusan egy 50 elem� karakter t�pus� t�mb�t.
    - T�lts�k fel v�letlenszer� abc karakterekkel ezt a t�mb�t elj�r�s seg�ts�g�vel.
    - A felhaszn�l� �ltal megadott indexn�l darabolja fel k�t m�sik karaktert�mbre az eredeti t�mb�t
      a szoftver! 
      F�ggv�nnyel �s elj�r�ssal is megoldhatj�k!
    - A felhaszn�l� �ltal megadott elemet t�r�lje ki a t�mbb�l szoftver!
      F�ggv�nnyel oldj�k meg ezt is!
    */
	unsigned char *C = new unsigned char[50];
	
	
	for (int i=0;i<50;i++)
	{
		C[i] = rand()%(122+1-97)+97;
        std::cout << C[i] << " ";
	}
	
    std::cout << std::endl;
    //az unsigned kulcszoval csak pozitiv szamokat fogunk letarolni.
    unsigned int element;
    unsigned int currentSize = 50;
    do {
        std::cin >> element;
    } while (element < 50 && !element); //addig olvasunk be szamot, ameddig a jo ertektartomanyba adja meg a felhasznalo erteket.
    splitArray(C, element, 50);
    clearElement(C, element, currentSize);
    clearElement(C, element, currentSize);
    clearElement(C, element, currentSize);

	delete[] C;
    
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
